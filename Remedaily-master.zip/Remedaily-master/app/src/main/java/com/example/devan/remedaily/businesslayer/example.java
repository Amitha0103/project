package com.example.devan.remedaily.businesslayer;

public class example {

    public String DemoBusinessLayerFunction(){
        return "This is a demo business layer function";
    }
}
