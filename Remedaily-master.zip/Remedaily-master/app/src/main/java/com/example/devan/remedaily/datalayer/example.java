package com.example.devan.remedaily.datalayer;

public class example {

    public String DemoBusinessLayerFunction(){
        return "This is a demo data layer function";
    }
}
